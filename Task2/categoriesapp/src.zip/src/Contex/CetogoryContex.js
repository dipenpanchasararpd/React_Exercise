import { createContext } from "react";

const CategoryContex = createContext();

export default CategoryContex;