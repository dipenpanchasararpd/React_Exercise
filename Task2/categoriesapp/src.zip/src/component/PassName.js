import React from 'react'
import Tags from './Tags'

function PassName() {
  return (
    <Tags/>
  )
}

export default PassName
