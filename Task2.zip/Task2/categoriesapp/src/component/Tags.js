import React from 'react'
<link rel="stylesheet"
href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link>

function Tags() {
    console.log("HEELO")
    return (
        <>
            <div className="row">
                <div class="side">
                    <div className='tagmenu'>
                        <h3>Tags</h3>
                        <button className='addbtn' >+</button>
                    </div>
                    <input type='text' className='tagSerch' placeholder='Search..'></input> 
                    <br></br>
                    
                </div>
                <div className="main">

                </div>
            </div>
        </>
    )
}

export default Tags
