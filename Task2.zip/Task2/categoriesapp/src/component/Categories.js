import React, { useState } from 'react'
import './Style.css';
import Popup from './Popup';
import { NavLink } from 'react-router-dom';




function Categories() {
    const [showModel, setShowmodel] = useState(false);
    const [category,setCategory] =useState('')


    const closePopup = () => setShowmodel(false)
    function handleDelete() {
        alert("Are You Sure You Want To delete This Tag??")
    }

    function sendData(){
        setShowmodel(true);
        setCategory('Category');
    }

    return (
        <>
            <link rel="stylesheet"
                href=
                "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></link>
            <div className="navbar">
                <h2>Categories</h2>
            </div>

            <div className="row">
                <div class="side">Categories</div>
                <div className="main">
                    <div>
                        <input className='search' type='text' placeholder='Search..'  />  <i style={{marginTop:10}} class="fa fa-search icon"></i>

                        <button className='btncreat' onClick={() => sendData()}> Create New Category </button>
                        {showModel && <Popup closePopup={{closePopup,category}} />}


                    </div>
                    <div className='categories'>
                        <table>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>

                            <tr>

                                <td><NavLink to='/Main'>automobile</NavLink></td>
                                <td>-</td>
                                <td><button onClick={() => setShowmodel(true)}>Edit</button><button onClick={() => handleDelete()}>Delete</button></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Categories
